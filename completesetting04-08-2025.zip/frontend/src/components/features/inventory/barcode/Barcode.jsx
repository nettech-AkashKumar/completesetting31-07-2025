import React from 'react'

const Barcode = () => {
  return (
    <div>Barcode</div>  
  )
}

export default Barcode