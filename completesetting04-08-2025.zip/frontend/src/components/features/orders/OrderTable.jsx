import React from 'react'

const OrderTable = () => {
  return (
    <div>OrderTable</div>
  )
}

export default OrderTable