import React from 'react'

const SupplierForm = () => {
  return (
    <div>SupplierForm</div>
  )
}

export default SupplierForm