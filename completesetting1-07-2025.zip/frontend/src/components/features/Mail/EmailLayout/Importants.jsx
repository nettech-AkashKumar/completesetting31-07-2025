import React from 'react'

const Importants = () => {
  return (
    <div>
      importants
    </div>
  )
}

export default Importants
