import React from 'react'

const StockTransfer = () => {
  return (
    <div>StockTransfer</div>
  )
}

export default StockTransfer