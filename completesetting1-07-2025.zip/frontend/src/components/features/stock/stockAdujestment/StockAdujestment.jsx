import React from 'react'

const StockAdujestment = () => {
  return (
    <div>StockAdujestment</div>
  )
}

export default StockAdujestment