import React from 'react'

const SupplierTable = () => {
  return (
    <div>SupplierTable</div>
  )
}

export default SupplierTable