// config.js
const BASE_URL = `http://localhost:5000`;
// const BASE_URL = `https://crmbackend-mn7w.onrender.com`;
export default BASE_URL;
